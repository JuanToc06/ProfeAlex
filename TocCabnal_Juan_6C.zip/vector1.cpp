#include <iostream>
using namespace std;
int main(){
	int vector[10] = {-2,-1,5,9,-12,16,-123,7,0};
	for(int i=0; i<10; i++){
		
		if(i==0){
			if(vector[i] < 0){
				cout<<"la primera posicion es negativa \n";
			}else{
				cout<<"la primera posicion es positiva \n";
			}
		}
		if(i==4){
			if(vector[i] > 0){
				cout<<"la quinta posicion es positiva \n";
			}else{
				cout<<"la quinta posicion es negativa \n";
			}
		}
		if(i==9){
			if (vector[i] == 0){
			cout<<"la ultima posicion es 0 \n";
			}else if(vector [i] < 0){
				cout<<"la ultima posicion es negativa \n";
			}else{
				cout<<"la ultima posicion es positva \n";
			}
		}	
	}
	return 0;
}
