#include <iostream>
using namespace std;
int main(){
	int vector[10] = {5,10,15,20,25,30,35,40,45,50};
	int suma = 0;
	int promedio;
	int ultimoprom;
	for(int i=0; i < 10; i++){
		suma += vector[i];
	}
	promedio = suma / 10;
	ultimoprom = suma / 4;
	cout<<" la suma es : "<<suma;
	cout<<" \n el promedio es : "<<promedio;
	cout<<"\n el promedio del 25 porciento es : "<<ultimoprom;
	return 0;
}
